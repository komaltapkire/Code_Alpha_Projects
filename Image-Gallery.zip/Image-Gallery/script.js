let currentIndex = 0;
const images = document.querySelectorAll('.gallery-item');
const modal = document.getElementById('imageModal');
const modalImage = document.getElementById('modalImage');

function openModal(index) {
  modal.style.display = 'flex';
  currentIndex = index;
  modalImage.src = images[index].src;
}

function closeModal() {
  modal.style.display = 'none';
}

function changeImage(step) {
  currentIndex += step;
  if (currentIndex < 0) {
    currentIndex = images.length - 1;
  } else if (currentIndex >= images.length) {
    currentIndex = 0;
  }
  modalImage.src = images[currentIndex].src;
}

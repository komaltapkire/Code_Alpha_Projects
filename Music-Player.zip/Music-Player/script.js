const songs = [
    {
        name: 'Shape of You',
        artist: 'Ed Sheeran',
        src: './songs/instrumental-presentation-186789.mp3'
    },
    {
        name: 'Blinding Lights',
        artist: 'The Weeknd',
        src: './songs/Luke-Bergs-Take-It-Easy(chosic.com).mp3'
    },
    {
        name: 'Levitating',
        artist: 'Dua Lipa',
        src: './songs/Luke-Bergs-Take-It-Easy(chosic.com).mp3'
    },
    {
        name: 'Claim Down',
        artist: 'Rema',
        src: './songs/Luke-Bergs-Take-It-Easy(chosic.com).mp3'
    },
    {
        name: 'Put It On Da Floor',
        artist: 'Latto',
        src: './songs/Luke-Bergs-Take-It-Easy(chosic.com).mp3'
    }
];

let currentSongIndex = 0;
let isLooping = false;
let isPlayingOnce = false;
const audio = new Audio();
audio.src = songs[currentSongIndex].src;

const songName = document.querySelector('.music-info h2');
const artistName = document.querySelector('.music-info p');
const playBtn = document.querySelector('.btn.play');
const nextBtn = document.querySelector('.btn.next');
const prevBtn = document.querySelector('.btn.prev');
const loopBtn = document.querySelector('.btn.loop');
const onceBtn = document.querySelector('.btn.once');
const progressBar = document.querySelector('.progress-bar');
const progressContainer = document.querySelector('.progress-container');

function loadSong(song) {
    songName.textContent = song.name;
    artistName.textContent = song.artist;
    audio.src = song.src;
}

function playSong() {
    audio.play();
    playBtn.innerHTML = '<i class="fas fa-pause"></i>';
    playBtn.classList.remove('play');
    playBtn.classList.add('pause');
}

function pauseSong() {
    audio.pause();
    playBtn.innerHTML = '<i class="fas fa-play"></i>';
    playBtn.classList.remove('pause');
    playBtn.classList.add('play');
}

function toggleLoop() {
    isLooping = !isLooping;
    loopBtn.classList.toggle('active', isLooping);
    audio.loop = isLooping;
}

function toggleOnce() {
    isPlayingOnce = !isPlayingOnce;
    onceBtn.classList.toggle('active', isPlayingOnce);
}

playBtn.addEventListener('click', () => {
    if (audio.paused) {
        playSong();
    } else {
        pauseSong();
    }
});

nextBtn.addEventListener('click', () => {
    currentSongIndex = (currentSongIndex + 1) % songs.length;
    loadSong(songs[currentSongIndex]);
    playSong();
});

prevBtn.addEventListener('click', () => {
    currentSongIndex = (currentSongIndex - 1 + songs.length) % songs.length;
    loadSong(songs[currentSongIndex]);
    playSong();
});

loopBtn.addEventListener('click', toggleLoop);
onceBtn.addEventListener('click', toggleOnce);

audio.addEventListener('ended', () => {
    if (isPlayingOnce) {
        audio.currentTime = 0;
        playSong();
    } else if (!isLooping) {
        nextBtn.click();
    }
});

audio.addEventListener('timeupdate', () => {
    const progressPercent = (audio.currentTime / audio.duration) * 100;
    progressBar.style.width = `${progressPercent}%`;
});

function setProgressBar(e) {
    const progressWidth = progressContainer.clientWidth;
    const clickX = e.clientX - progressContainer.offsetLeft;
    const newTime = (clickX / progressWidth) * audio.duration;
    audio.currentTime = newTime;
}

progressContainer.addEventListener('click', setProgressBar);
progressContainer.addEventListener('mousedown', (e) => {
    setProgressBar(e);
    document.addEventListener('mousemove', setProgressBar);
});
document.addEventListener('mouseup', () => {
    document.removeEventListener('mousemove', setProgressBar);
});

// Load the initial song
loadSong(songs[currentSongIndex]);

let transactions = [];
let totalIncome = 0;
let totalExpenses = 0;
let balance = 0;

function addTransaction() {
  const date = document.getElementById("date").value;
  const description = document.getElementById("description").value;
  const amount = parseFloat(document.getElementById("amount").value);
  const type = document.getElementById("type").value;

  if (description === "" || isNaN(amount) || amount <= 0) {
    alert("Please fill in all fields correctly.");
    return;
  }

  const transaction = {
    date,
    description,
    amount,
    type,
  };

  transactions.push(transaction);
  updateTotalsAndBalance();
  displayTransactions();
  resetForm();
}

function updateTotalsAndBalance() {
  totalIncome = 0;
  totalExpenses = 0;

  transactions.forEach((transaction) => {
    if (transaction.type === "income") {
      totalIncome += transaction.amount;
    } else {
      totalExpenses += transaction.amount;
    }
  });

  balance = totalIncome - totalExpenses;

  document.getElementById("total-income").innerText = `$${totalIncome.toFixed(
    2
  )}`;
  document.getElementById(
    "total-expenses"
  ).innerText = `$${totalExpenses.toFixed(2)}`;
  document.getElementById("balance").innerText = `$${balance.toFixed(2)}`;
}

function displayTransactions() {
  const transactionsList = document.getElementById("transactions-list");
  transactionsList.innerHTML = "";

  transactions.forEach((transaction) => {
    const row = document.createElement("tr");
    row.innerHTML = `
            <td>${transaction.date}</td>
            <td>${transaction.description}</td>
            <td>${transaction.amount.toFixed(2)}</td>
            <td>${
              transaction.type.charAt(0).toUpperCase() +
              transaction.type.slice(1)
            }</td>
        `;
    transactionsList.appendChild(row);
  });
}

function resetForm() {
  document.getElementById("date").value = "";
  document.getElementById("description").value = "";
  document.getElementById("amount").value = "";
  document.getElementById("type").value = "income";
}

document
  .getElementById("add-transaction")
  .addEventListener("click", addTransaction);
